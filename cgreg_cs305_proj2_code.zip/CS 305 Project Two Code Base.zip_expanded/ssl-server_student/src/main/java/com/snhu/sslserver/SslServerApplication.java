package com.snhu.sslserver;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}
	
@RestController
class ServerController{
	
/*
 *  Takes a string value and returns the hashed value utilizing the MessageDigest algorithm SHA-256.
 */
	public String hashFunction(String toHash) throws NoSuchAlgorithmException {
		
	// Initialize SHA-256 as MessageDigest algorithm.
	MessageDigest SHA = MessageDigest.getInstance("SHA-384");
	
	// Generates hash value of byte type.
	byte[] byteArray = SHA.digest(toHash.getBytes());
	
	// Converts bytes into hex using BigInteger object via https://www.geeksforgeeks.org/java-program-to-convert-byte-array-to-hex-string/
	String hexed = new BigInteger(1, byteArray).toString(16);
	
	return hexed;
	}
	
/*
 * Adds hash function to return the checksum value for the data string "Cody Gregory".
 */   
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Cody Gregory's Project Two Checksum!";
       
    	try {
			String hashed = hashFunction(data);
			
			// If hashFunction is successful returns CheckSum value. <br> instead of \n to create page break in HTML.
			return "Data: " + data + "<br>" + "SHA-384: CheckSum Value: " + hashed;
			
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
    	
    	// If hashFunction failed notifies user.
    	return "Hash not available, an error has occurred.";
    }
}

